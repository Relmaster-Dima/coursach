// src/main/java/com/pcclub/model/PaymentMethod.java
package com.pcclub.model;

public enum PaymentMethod {
    CASH, CARD, BALANCE
}
