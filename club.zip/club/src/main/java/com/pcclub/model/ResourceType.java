package com.pcclub.model;

public enum ResourceType {
    COMPUTER,
    CONSOLE
}
