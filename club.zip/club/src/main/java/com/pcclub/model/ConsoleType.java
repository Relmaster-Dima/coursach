package com.pcclub.model;

public enum ConsoleType {
    PS5,
    XBOX,
    NINTENDO
}
