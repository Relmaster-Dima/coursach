package com.pcclub.model;

public enum Role {
    ADMIN, MANAGER, CLIENT
}
