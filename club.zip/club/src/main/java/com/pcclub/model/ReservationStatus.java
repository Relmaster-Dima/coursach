package com.pcclub.model;

public enum ReservationStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
}
